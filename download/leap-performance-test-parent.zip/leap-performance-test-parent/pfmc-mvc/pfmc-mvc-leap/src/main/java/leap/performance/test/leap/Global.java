package leap.performance.test.leap;

import leap.web.App;

public class Global extends App {

}
