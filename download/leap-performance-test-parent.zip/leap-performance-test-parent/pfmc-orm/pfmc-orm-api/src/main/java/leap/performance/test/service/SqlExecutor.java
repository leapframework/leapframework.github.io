package leap.performance.test.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface SqlExecutor<T> {
	public T selectById(Object id);
	public void insert(T t);
	public void beathInsert(Collection<T> collection);
	public void update(T t);
	public void beathDelete(Collection<?> ids);
	public void deleteAll();
	public void deleteById(Object id);
	
	public List<T> dynamicSql(Map<String, Object> params);
	public List<?> joinSql(Map<String, Object> params);
	
	public List<T> select(String sqlKey, Map<String, Object> params);
}
