/* shv */
CREATE TABLE `shv_user`(  
  `id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(50),
  `login_id` VARCHAR(50),
  `password` VARCHAR(50),
  `created_at` TIMESTAMP,
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_general_ci;

/* smv */
CREATE TABLE `smv_user`(  
  `id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(50),
  `login_id` VARCHAR(50),
  `password` VARCHAR(50),
  `created_at` TIMESTAMP,
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_general_ci;
/* smt */
CREATE TABLE `smt_user`(  
  `id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(50),
  `login_id` VARCHAR(50),
  `password` VARCHAR(50),
  `created_at` TIMESTAMP,
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_general_ci;

/* leap */
CREATE TABLE `leap_user`(  
  `id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(50),
  `login_id` VARCHAR(50),
  `password` VARCHAR(50),
  `created_at` TIMESTAMP,
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_general_ci;