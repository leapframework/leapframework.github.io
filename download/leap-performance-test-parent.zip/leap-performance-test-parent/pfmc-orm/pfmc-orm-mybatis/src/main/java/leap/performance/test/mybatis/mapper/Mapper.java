package leap.performance.test.mybatis.mapper;

import java.util.Collection;
import java.util.List;
import java.util.Map;


public interface Mapper<T> {
	public T selectById(Object id);
	public List<T> select(Map<String, Object> params);
	public void insert(T t);
	public void beathInsert(Collection<T> collection);
	public void update(T t);
	public void beathDelete(Collection<?> ids);
	public void deleteById(Object id);
	public void deleteAll();
	
	public List<T> dynamicSql(Map<String, Object> params);
	public List<?> joinSql(Map<String, Object> params);
}
