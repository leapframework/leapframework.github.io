package leap.performance.test.model;

public interface Company{
	public String getId();
	public void setId(String id);
	public String getName();
	public void setName(String name);
	public Integer getMemberNum();
	public void setMemberNum(Integer memberNum);
}
