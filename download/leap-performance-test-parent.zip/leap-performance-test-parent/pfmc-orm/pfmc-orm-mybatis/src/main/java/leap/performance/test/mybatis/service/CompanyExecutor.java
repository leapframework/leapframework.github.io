package leap.performance.test.mybatis.service;

import leap.performance.test.mybatis.mapper.CompanyMapper;
import leap.performance.test.mybatis.model.Company;

public class CompanyExecutor extends BaseExecutor<Company, CompanyMapper> {
	@Override
	protected Class<CompanyMapper> getMapperType() {
		return CompanyMapper.class;
	}
}
