package leap.performance.test.engine.instance;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Map;

import leap.core.AppContext;
import leap.htpl.DefaultHtplContext;
import leap.htpl.HtplContext;
import leap.htpl.HtplEngine;
import leap.htpl.HtplTemplate;
import leap.performance.test.engine.TemplateEngine;

public class Htpl implements TemplateEngine{
	private HtplEngine engine;
	private String template;
	public Htpl(String tmplPath) {
		init(null);
	}
	@Override
	public TemplateEngine init(String tmplPath) {
		engine = AppContext.getBean(HtplEngine.class);
		return this;
	}

	@Override
	public String process(Map<String, Object> map) {
		HtplTemplate template = engine.resolveTemplate(this.template);
		HtplContext context = new DefaultHtplContext(engine);
		context.putVariables(map);
		StringWriter writer = new StringWriter();
		template.render(context, writer);
		String result = writer.toString();
		try {
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public void testTemplateName(String name) {
		this.template = name;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
}
