package leap.performance.test.spring.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import leap.performance.test.model.CollectionModel;
import leap.performance.test.model.JsonModel;
import leap.performance.test.model.ParamModel;
import leap.performance.test.model.User;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller("/")
public class HomeController {
	@RequestMapping("")
	public ModelAndView index(String name,
			ParamModel pm,
			CollectionModel cm) {
		ModelAndView mv = new ModelAndView("index");
		List<User> users = new ArrayList<User>();
		for(int i = 0; i < 500; i++){
			User user = new User();
			user.setName(name+i);
			user.setAge(i);
			users.add(user);
		}
		mv.addObject("pm", pm);
		mv.addObject("cm", cm);
		mv.addObject("users", users);
		return mv;
	}
	@RequestMapping("json")
	@ResponseBody
	public JsonModel json(){
		JsonModel jm = new JsonModel();
		jm.setName("json");
		jm.setAge(40);
		List<User> users = new ArrayList<User>();
		for(int i=0; i < 200; i ++){
			User user = new User();
			user.setName("user"+i);
			user.setAge(i);
			users.add(user);
		}
		jm.setUser(users);
		Map<String, Object> attr = new HashMap<>();
		attr.put("name", "jm");
		attr.put("age", 30);
		jm.setAttr(attr);
		return jm;
	}
}
