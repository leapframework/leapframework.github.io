package leap.performance.test.leap.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import leap.lang.New;
import leap.performance.test.leap.model.Blog;

public class BlogExecutor extends BaseExecutor<Blog> {
	public static final String selectBlogById="selectBlogById";
	public static final String insertBlog = "insertBlog";
	public static final String updateBlog = "updateBlog";
	public static final String deleteBlogById = "deleteBlogById";
	public static final String beathBlogDelete = "beathBlogDelete";
	public static final String deleteAllBlog = "deleteAllBlog";
	
	@Override
	public void insert(Blog t) {
		dao.executeNamedUpdate(insertBlog, t.toMap());
	}

	@Override
	public Blog selectById(Object id) {
		return Blog.<Blog>query(selectBlogById).param("id", id).firstOrNull();
	}

	@Override
	public void beathInsert(Collection<Blog> collection) {
		for(Blog blog : collection){
			insert(blog);
		}
	}

	@Override
	public void update(Blog t) {
		dao.executeNamedUpdate(updateBlog, t.toMap());
	}

	@Override
	public void beathDelete(Collection<?> ids) {
		dao.executeNamedUpdate(beathBlogDelete, New.hashMap("ids", ids.toArray()));
	}

	@Override
	public void deleteAll() {
		dao.executeNamedUpdate(deleteAllBlog, New.hashMap());
	}

	@Override
	public void deleteById(Object id) {
		dao.executeNamedUpdate(deleteBlogById, New.hashMap("id",id));
	}

	@Override
	public List<Blog> select(String sqlKey, Map<String, Object> params) {
		List<Blog> list = Blog.<Blog>query(sqlKey).params(params).list();
		return list;
	}

	@Override
	public List<Blog> dynamicSql(Map<String, Object> params) {
		//暂不测试到此部分
		return New.arrayList();
	}

	@Override
	public List<?> joinSql(Map<String, Object> params) {
		//暂不测试到此部分
		return New.arrayList();
	}
}
