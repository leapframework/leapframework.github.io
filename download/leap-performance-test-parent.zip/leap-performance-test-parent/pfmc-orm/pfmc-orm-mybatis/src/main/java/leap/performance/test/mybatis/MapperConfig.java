package leap.performance.test.mybatis;

public class MapperConfig {
	private Class<?> type;
	private String resource;
	public MapperConfig(String clzz, String resource) throws ClassNotFoundException {
		super();
		this.type = Class.forName(clzz);
		this.resource = resource;
	}
	public Class<?> getType() {
		return type;
	}
	public void setType(Class<?> type) {
		this.type = type;
	}
	public String getResource() {
		return resource;
	}
	public void setResource(String resource) {
		this.resource = resource;
	}
}
