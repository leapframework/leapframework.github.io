package leap.performance.test.mybatis.service;

import leap.performance.test.model.Blog;
import leap.performance.test.model.Company;
import leap.performance.test.model.User;

public class DataService implements leap.performance.test.service.DataService{

	@Override
	public Class<? extends Company> companyClass() {
		return leap.performance.test.mybatis.model.Company.class;
	}

	@Override
	public Class<? extends User> userClass() {
		return leap.performance.test.mybatis.model.User.class;
	}

	@Override
	public Class<? extends Blog> blogClass() {
		return leap.performance.test.mybatis.model.Blog.class;
	}

}
