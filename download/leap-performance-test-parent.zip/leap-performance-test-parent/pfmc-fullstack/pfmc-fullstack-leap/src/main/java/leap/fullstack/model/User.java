package leap.fullstack.model;

import java.sql.Timestamp;

import leap.orm.annotation.Column;
import leap.orm.annotation.Table;
import leap.orm.model.Model;

@Table("leap_user")
public class User extends Model {
	@Column(name="id")
	private String id;
	@Column(name="name")
	private String name;
	@Column(name="login_id")
	private String loginId;
	@Column(name="password")
	private String password;
	@Column(name="created_at")
	private Timestamp createdAt;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
}
