package leap.performance.test;

import leap.core.annotation.Inject;
import leap.performance.test.service.OrmTestService;
import leap.web.App;

public class Global extends App {
	@Inject
	private OrmTestService service;
	
	@Override
	protected void init() throws Throwable {
		service.initDatabase("mybatis");
	}
	
	public void initDatabase(){}
}
