package leap.performance.test.mybatis.mapper;

import leap.performance.test.mybatis.model.Blog;


public interface BlogMapper extends Mapper<Blog> {
}
