package leap.performance.test.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;

import leap.performance.test.model.Blog;
import leap.performance.test.model.Company;
import leap.performance.test.model.User;

public interface DataService {
	public int companyNum = 10;
	public int userNum = 100;
	public int blogNum = 1000;
	public final int userAge = 500;
	public final String userName = "2";
	public final String companyName = "company";
	public final String blogTitle = "title";
	
	public static final Random random = new Random();
	public static final int BOUND = 1000;
	default List<Company> company(){
		List<Company> companys = new ArrayList<Company>();
		for(int i=0; i < companyNum; i++){
			companys.add(genCompany(UUID.randomUUID().toString()));
		}
		return companys;
	}
	default List<User> user(List<Company> companys){
		List<User> users = new ArrayList<User>();
		int comSize = companys.size();
		for(int i=0; i < userNum; i++){
			int index = new Random().nextInt(comSize);
			Company com = companys.get(index);
			users.add(genUser(UUID.randomUUID().toString(),com));
			if(Objects.equals(null, com.getMemberNum())||com.getMemberNum()==0){
				com.setMemberNum(1);
			}else{
				com.setMemberNum(com.getMemberNum()+1);
			}
		}
		return users;
	}
	default List<Blog> blog(List<User> users){
		List<Blog> blogs = new ArrayList<Blog>();
		int userSize = users.size();
		for(int i=0; i < blogNum; i++){
			int index = new Random().nextInt(userSize);
			User user = users.get(index);
			blogs.add(genBlog(UUID.randomUUID().toString(),user));
		}
		return blogs;
	}
	default Company genCompany(String id){
		Company company = null;
		try {
			company = companyClass().newInstance();
			company.setId(id);
			company.setName(companyName);
			
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return company;
	};
	default User genUser(String id,Company company){
		User user = null;
		try {
			user = userClass().newInstance();
			user.setAge(userAge);
			user.setCompanyId(company.getId());
			user.setName(userName);
			user.setId(id);
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return user;
	};
	default Blog genBlog(String id,User author){
		Blog blog = null;
		try {
			blog = blogClass().newInstance();
			blog.setId(id);
			blog.setAuthorId(author.getId());
			blog.setCreatedAt(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			blog.setTitle(blogTitle);
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return blog;
	};
	public Class<? extends Company> companyClass();
	public Class<? extends User> userClass();
	public Class<? extends Blog> blogClass();
	
}
