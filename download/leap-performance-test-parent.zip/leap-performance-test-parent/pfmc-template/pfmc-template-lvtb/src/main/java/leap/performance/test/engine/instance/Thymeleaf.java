package leap.performance.test.engine.instance;

import java.util.Map;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templateresolver.FileTemplateResolver;
import org.thymeleaf.templateresolver.TemplateResolver;

public class Thymeleaf implements leap.performance.test.engine.TemplateEngine{
	private TemplateEngine templateEngine;
	private TemplateResolver templateResolver;
	private String template;
	public Thymeleaf(String tmplPath) {
		init(tmplPath);
	}
	@Override
	public leap.performance.test.engine.TemplateEngine init(String tmplPath) {
		templateResolver = new FileTemplateResolver();
		templateResolver.setTemplateMode("XHTML");
		templateResolver.setPrefix(rootPath());
		templateResolver.setSuffix("");
		templateResolver.setCacheTTLMs(3600000L);
		templateEngine =  new TemplateEngine();
		templateEngine.setTemplateResolver(templateResolver);
		return this;
	}

	@Override
	public String process(Map<String, Object> map) {
		Context context = new Context();
		context.setVariables(map);
		return templateEngine.process(template, context);
	}
	@Override
	public void testTemplateName(String name) {
		this.template = name;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
}
