package leap.performance.test.leap.model;

import java.util.Map;

import leap.lang.New;
import leap.orm.annotation.Column;
import leap.orm.annotation.Id;
import leap.orm.annotation.Table;
import leap.orm.model.Model;

@Table("leap_user")
public class User extends Model implements leap.performance.test.model.User,Mapper{
	@Id
	@Column(name="id")
	private String id;
	@Column(name="name")
	private String name;
	@Column(name="age")
	private Integer age;
	@Column(name="company_id")
	private String companyId;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	@Override
	public Map<String, Object> toMap() {
		Map<String, Object> map = New.hashMap();
		map.put("id", id);
		map.put("name", name);
		map.put("age", age);
		map.put("companyId", companyId);
		return map;
	}
}
