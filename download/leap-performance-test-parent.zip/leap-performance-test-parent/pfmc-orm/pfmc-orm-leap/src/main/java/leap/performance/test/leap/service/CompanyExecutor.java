package leap.performance.test.leap.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import leap.lang.New;
import leap.performance.test.leap.model.Company;

public class CompanyExecutor extends BaseExecutor<Company> {
	public static final String selectCompanyById="selectCompanyById";
	public static final String insertCompany = "insertCompany";
	public static final String updateCompany = "updateCompany";
	public static final String deleteCompanyById = "deleteCompanyById";
	public static final String beathCompanyDelete = "beathCompanyDelete";
	public static final String deleteAllCompany = "deleteAllCompany";
	
	@Override
	public void insert(Company t) {
		dao.executeNamedUpdate(insertCompany, t.toMap());
	}

	@Override
	public Company selectById(Object id) {
		return Company.<Company>query(selectCompanyById).param("id", id).firstOrNull();
	}

	@Override
	public void beathInsert(Collection<Company> collection) {
		for(Company company : collection){
			insert(company);
		}
	}

	@Override
	public void update(Company t) {
		dao.executeNamedUpdate(updateCompany, t.toMap());
	}

	@Override
	public void beathDelete(Collection<?> ids) {
		dao.executeNamedUpdate(beathCompanyDelete, New.hashMap("ids", ids.toArray()));
	}

	@Override
	public void deleteAll() {
		dao.executeNamedUpdate(deleteAllCompany, New.hashMap());
	}

	@Override
	public void deleteById(Object id) {
		dao.executeNamedUpdate(deleteCompanyById, New.hashMap("id",id));
	}

	@Override
	public List<Company> select(String sqlKey, Map<String, Object> params) {
		List<Company> list = Company.<Company>query(sqlKey).params(params).list();
		return list;
	}

	@Override
	public List<Company> dynamicSql(Map<String, Object> params) {
		//暂不测试到此部分
		return New.arrayList();
	}

	@Override
	public List<?> joinSql(Map<String, Object> params) {
		//暂不测试到此部分
		return New.arrayList();
	}
}
