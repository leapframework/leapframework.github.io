package leap.performance.test.service;

import java.util.List;

import leap.core.AppContext;
import leap.db.Db;
import leap.db.model.DbColumn;
import leap.db.model.DbColumnBuilder;
import leap.db.model.DbTableBuilder;

public interface OrmTestService {
	public void clearTestData();
	public void insertTestData(int num);
	public void updateTestData(int num);
	public void deletedTestData(int num);
	public List<?> selectTestData(int num);
	public List<?> dynamicSql(int num);
	public List<?> joinSql(int num);
	
	default void initDatabase(String tablePrefix){
		Db db = AppContext.current().getBeanFactory().getBean(Db.class);
		if(!db.getDialect().supportsColumnComment()){
			return;
		}
		try{
			DbColumn blogId = DbColumnBuilder.varchar("id", 36).setComment("主键").setPrimaryKey(true).build();
			DbColumn blogTitle = DbColumnBuilder.varchar("title", 50).setComment("主题").build();
			DbColumn blogAuthorId = DbColumnBuilder.varchar("author_id",36).setComment("作者").build();
			DbColumn blogCreatedAt = DbColumnBuilder.timestamp("created_at").setComment("创建时间").build();
			
			DbTableBuilder blog = new DbTableBuilder(tablePrefix+"_blog")
					.addColumn(blogId).addColumn(blogTitle).addColumn(blogAuthorId)
					.addColumn(blogCreatedAt);
			
			DbColumn userId = DbColumnBuilder.varchar("id", 36).setComment("主键").setPrimaryKey(true).build();
			DbColumn userName = DbColumnBuilder.varchar("name", 50).setComment("姓名").build();
			DbColumn userAge = DbColumnBuilder.integer("age").setComment("年龄").build();
			DbColumn userCompanyId = DbColumnBuilder.varchar("company_id", 36).setComment("公司id").build();
			
			DbTableBuilder user = new DbTableBuilder(tablePrefix+"_user")
					.addColumn(userId).addColumn(userName).addColumn(userAge)
					.addColumn(userCompanyId);
			
			DbColumn companyId = DbColumnBuilder.varchar("id", 36).setComment("主键").setPrimaryKey(true).build();
			DbColumn companyName = DbColumnBuilder.varchar("name", 50).setComment("名称").build();
			DbColumn companyMemberNum = DbColumnBuilder.integer("member_num").setComment("员工数量").build();
			DbTableBuilder company = new DbTableBuilder(tablePrefix+"_company")
			.addColumn(companyId).addColumn(companyName).addColumn(companyMemberNum);
			if(!db.checkTableExists(company.getName())){
				db.cmdCreateTable(company.build()).execute();
			}
			if(!db.checkTableExists(user.getName())){
				db.cmdCreateTable(user.build()).execute();
			}
			if(!db.checkTableExists(blog.getName())){
				db.cmdCreateTable(blog.build()).execute();
			}
		}catch(Exception e){
			throw e;
		}
	}
	default int num(int num){
		if(num == 0){
			num = 1;
		}
		return num;
	}
}
