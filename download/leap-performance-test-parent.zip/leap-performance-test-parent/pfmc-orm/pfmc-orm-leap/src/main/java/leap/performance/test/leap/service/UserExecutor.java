package leap.performance.test.leap.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import leap.core.value.Record;
import leap.lang.New;
import leap.performance.test.leap.model.User;

public class UserExecutor extends BaseExecutor<User> {
	public static final String selectUserById="selectUserById";
	public static final String insertUser = "insertUser";
	public static final String updateUser = "updateUser";
	public static final String deleteUserById = "deleteUserById";
	public static final String beathUserDelete = "beathUserDelete";
	public static final String deleteAllUser = "deleteAllUser";
	
	@Override
	public void insert(User t) {
		dao.executeNamedUpdate(insertUser, t.toMap());
	}

	@Override
	public User selectById(Object id) {
		return User.<User>query(selectUserById).param("id", id).singleOrNull();
	}

	@Override
	public void beathInsert(Collection<User> collection) {
		for(User user : collection){
			insert(user);
		}
	}

	@Override
	public void update(User t) {
		dao.executeNamedUpdate(updateUser, t.toMap());
	}

	@Override
	public void beathDelete(Collection<?> ids) {
		dao.executeNamedUpdate(beathUserDelete, New.hashMap("ids", ids.toArray()));
	}

	@Override
	public void deleteAll() {
		dao.executeNamedUpdate(deleteAllUser, New.hashMap());
	}

	@Override
	public void deleteById(Object id) {
		dao.executeNamedUpdate(deleteUserById, New.hashMap("id",id));
	}

	@Override
	public List<User> select(String sqlKey, Map<String, Object> params) {
		List<User> list = User.<User>query(sqlKey).params(params).list();
		return list;
	}

	@Override
	public List<User> dynamicSql(Map<String, Object> params) {
		List<User> list = User.<User>query("dynamicSql").params(params).list();
		return list;
	}

	@Override
	public List<?> joinSql(Map<String, Object> params) {
		List<Record> list = dao.createNamedQuery("joinSql").list();
		return list;
	}
}
