package leap.performance.test.leap.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import leap.core.annotation.Inject;
import leap.performance.test.model.Blog;
import leap.performance.test.model.Company;
import leap.performance.test.model.User;
import leap.performance.test.service.DataService;
import leap.performance.test.service.OrmTestService;
import leap.performance.test.service.SqlExecutor;

public class LeapTestService implements OrmTestService {
	public static final String selectUserList = "selectUserList";
	public static final String selectCompanyList = "selectCompanyList";
	public static final String selectBlogList = "selectBlogList";
	public static final String dynamicSql = "dynamicSql";
	
	@Inject(name = "leapUserExecutor")
	private SqlExecutor<User> user;
	@Inject(name = "leapBlogExecutor")
	private SqlExecutor<Blog> blog;
	@Inject(name = "leapCompanyExecutor")
	private SqlExecutor<Company> company;
	@Inject(name = "leapData")
	private DataService data;

	@Override
	public void clearTestData() {
		blog.deleteAll();
		user.deleteAll();
		company.deleteAll();
	}

	@Override
	public void insertTestData(int num) {
		num = num(num);
		for(int i = 0; i < num; i++){
			List<Company> companys = data.company();
			List<User> users = data.user(companys);
			List<Blog> blogs = data.blog(users);
			company.beathInsert(companys);
			user.beathInsert(users);
			blog.beathInsert(blogs);
		}
	}

	@Override
	public void updateTestData(int num) {
		num = num(num);
		Map<String, Object> cparams = new HashMap<String, Object>();
		cparams.put("count", 2);
		for(int i = 0; i < num; i++){
			List<Company> companys = company.select(selectCompanyList, cparams);
			for(Company company : companys){
				company.setName(company.getName()+1);
				this.company.update(company);
			}
		}
	}

	@Override
	public void deletedTestData(int num) {
		num = num(num);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("count", 2);
		List<Blog> blogs = blog.select(selectBlogList, params);
		for(Blog blog : blogs){
			this.blog.deleteById(blog.getId());
		}
	}

	@Override
	public List<?> selectTestData(int num) {
		num = num(num);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("count", 2);
		List<Object> list = new ArrayList<Object>();
		for(int i=0;i<num;i++){
			list.addAll(user.select(selectUserList, params));
			list.addAll(company.select(selectCompanyList, params));
			list.addAll(blog.select(selectBlogList, params));
		}
		return list;
	}

	@Override
	public List<?> dynamicSql(int num) {
		num = num(num);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", DataService.userName);
		params.put("age", DataService.userAge);
		
		List<Object> list = new ArrayList<Object>();
		for(int i=0;i<num;i++){
			list.addAll(user.select(dynamicSql, params));
		}
		return list;
	}

	@Override
	public List<?> joinSql(int num) {
		num = num(num);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", DataService.userName);
		params.put("title", DataService.blogTitle);
		
		List<Object> list = new ArrayList<Object>();
		for(int i=0;i<num;i++){
			list.addAll(user.joinSql(params));
		}
		return list;
	}

}
