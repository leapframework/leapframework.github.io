package leap.performance.test.engine.instance;

import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;

import leap.performance.test.engine.TemplateEngine;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;

public class Velocity implements TemplateEngine {
	private String template;
	public Velocity(String tmplPath) {
		init(tmplPath);
	}
	@Override
	public TemplateEngine init(String tmplPath) {
		String path = rootPath();
		Properties p = new Properties();
		p.setProperty("file.resource.loader.path", path);
		p.setProperty("input.encoding", "UTF-8");
		p.setProperty("output.encoding", "UTF-8");
		org.apache.velocity.app.Velocity.init(p);
		return this;
	}
	@Override
	public String process(Map<String, Object> map) {
		Template template = null;
		try {
			template = org.apache.velocity.app.Velocity.getTemplate(this.template);
			template.setEncoding("UTF-8");
		} catch (ResourceNotFoundException rnfe) {
			throw new RuntimeException(rnfe);
		} catch (ParseErrorException pee) {
			throw new RuntimeException(pee);
		} catch (MethodInvocationException mie) {
			throw new RuntimeException(mie);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		StringWriter sw = new StringWriter();
		VelocityContext context = new VelocityContext(map);
		template.merge(context, sw);
		return sw.toString();
	}
	@Override
	public void testTemplateName(String name) {
		this.template = name;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
}
