package leap.performance.test.leap.model;

import java.sql.Timestamp;
import java.util.Map;

import leap.lang.New;
import leap.orm.annotation.Column;
import leap.orm.annotation.Id;
import leap.orm.annotation.Table;
import leap.orm.model.Model;

@Table("leap_blog")
public class Blog extends Model implements leap.performance.test.model.Blog,Mapper{
	@Id
	@Column(name="id")
	private String id;
	@Column(name="title")
	private String title;
	@Column(name="author_id")
	private String authorId;
	@Column(name="created_at")
	private Timestamp createdAt;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthorId() {
		return authorId;
	}
	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}
	public Timestamp getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
	@Override
	public Map<String, Object> toMap() {
		Map<String, Object> map = New.hashMap();
		map.put("id", id);
		map.put("title", title);
		map.put("authorId", authorId);
		map.put("createdAt", createdAt);
		return map;
	}
}
