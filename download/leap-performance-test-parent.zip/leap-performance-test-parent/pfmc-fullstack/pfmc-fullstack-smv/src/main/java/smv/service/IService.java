package smv.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public interface IService<T> {
	public static final Random RANDOM = new Random();
	public static final int BOUND = 1000;
	public static final int NUM = 10;
	public static final String USERNAME = "user";
	public static final String LOGINID = "loginid";
	public static final String PASSWORD = "password";
	public T created(String name, String loginId, String password);
	public int randomUpdate();
	public int randomDelete();
	public List<T> selectRandomsize();
	default Timestamp now(){
		return new Timestamp(Calendar.getInstance().getTimeInMillis());
	}
}
