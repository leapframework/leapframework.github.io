package leap.performance.test.service;

import java.util.ArrayList;
import java.util.List;

import leap.core.annotation.Bean;
import leap.performance.test.model.User;
@Bean
public class DataService {
	public List<User> users(int num){
		List<User> users = new ArrayList<User>();
		for(int i=0; i < num; i++){
			User user = new User();
			user.setAge(i);
			user.setName("user"+i);
			users.add(user);
		}
		return users;
	}
}
