package leap.performance.test.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import leap.core.annotation.Inject;
import leap.lang.New;
import leap.performance.test.model.Company;
import leap.performance.test.mybatis.service.MybatisTestService;
import leap.performance.test.service.OrmTestService;
import leap.performance.test.service.SqlExecutor;

public class HomeController implements Controller{
	@Inject
	private OrmTestService service;
	@Override
	public Object index(int num) {
		if(num == 0){
			num = 1;
		}
		String companyId = UUID.randomUUID().toString();
		Company company = new leap.performance.test.mybatis.model.Company();
		company.setId(companyId);
		company.setMemberNum(300);
		company.setName("准备删除的公司");
		this.company.insert(company);
		company.setName("准备删除的公司1");
		this.company.update(company);
		this.company.deleteById(companyId);
		
		List<Object> list = New.arrayList();
		List<?> dynamic = service.dynamicSql(num);
		List<?> join = service.joinSql(num);
		list.addAll(dynamic);
		list.addAll(join);
		return list;
	}
	@Override
	public Object insert(int num) {
		service.insertTestData(num);
		return "true";
	}
	@Override
	public Object delete(int num) {
		service.deletedTestData(num);
		return "true";
	}
	@Override
	public Object update(int num) {
		service.updateTestData(num);
		return "true";
	}
	@Override
	public Object query(int num) {
		List<Object> list = New.arrayList();
		list.addAll(service.selectTestData(num));
		list.addAll(service.dynamicSql(num));
		return list;
	}
	@Override
	public Object testData() {
		service.insertTestData(1);
		return "true";
	}
	@Override
	public Object clearData() {
		service.clearTestData();
		return "true";
	}
	@Inject(name="mybatisCompanyExecutor")
	private SqlExecutor<Company> company;
	@Override
	public Object created(int num){
		List<Company> coms = New.arrayList();
		for(int i = 0; i < num; i++){
			Company com = new leap.performance.test.mybatis.model.Company();
			com.setId(UUID.randomUUID().toString());
			com.setMemberNum(0);
			com.setName("公司"+i);
			company.insert(com);
			coms.add(com);
		}
		return coms;
	}
	@Override
	public Object updated(int num) {
		List<Company> list = New.arrayList();
		for(int i =0 ; i < num; i++){
			Map<String, Object> cparams = new HashMap<String, Object>();
			cparams.put("count", 1);
			List<Company> coms = company.select(MybatisTestService.SQL_KEY, cparams);
			for(Company com : coms){
				list.add(com);
				com.setName(com.getName()+"1");
				company.update(com);
			}
		}
		return list;
	}
	@Override
	public Object deleted(int num) {
		List<Company> list = New.arrayList();
		for(int i =0 ; i < num; i++){
			Map<String, Object> cparams = new HashMap<String, Object>();
			cparams.put("count", 1);
			List<Company> coms = company.select(MybatisTestService.SQL_KEY, cparams);
			for(Company com : coms){
				list.add(com);
				company.deleteById(com.getId());
			}
		}
		return list;
	}
	@Override
	public Object dynamic(int num) {
		List<?> dynamic = service.dynamicSql(num);
		return dynamic;
	}
	@Override
	public Object join(int num) {
		List<?> join = service.joinSql(num);
		return join;
	}
}
