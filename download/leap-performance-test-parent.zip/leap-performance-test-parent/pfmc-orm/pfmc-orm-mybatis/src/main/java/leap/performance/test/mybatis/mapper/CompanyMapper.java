package leap.performance.test.mybatis.mapper;

import leap.performance.test.mybatis.model.Company;


public interface CompanyMapper extends Mapper<Company>{
}
