package leap.performance.test.model;

public class DefaultPerformance implements Performance{
	public double tps = 0;
	public long time = 0;
	public long count = 0;
	public String name;
	public int singleNout;
	public long totalNout;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getTps() {
		return tps;
	}

	public void setTps(double tps) {
		this.tps = tps;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	@Override
	public double tps() {
		return tps;
	}

	@Override
	public long time() {
		return time;
	}

	@Override
	public double singleNio() {
		return 0;
	}

	@Override
	public long totalNio() {
		return 0;
	}

	@Override
	public int singleNout() {
		return singleNout;
	}

	@Override
	public long totalNout() {
		return totalNout;
	}

	@Override
	public int sio() {
		return 0;
	}

	@Override
	public int sout() {
		return 0;
	}

	@Override
	public long memory() {
		return 0;
	}

	@Override
	public String engine() {
		return name;
	}

	public int getSingleNout() {
		return singleNout;
	}

	public void setSingleNout(int singleNout) {
		this.singleNout = singleNout;
	}

	public long getTotalNout() {
		return totalNout;
	}

	public void setTotalNout(long totalNout) {
		this.totalNout = totalNout;
	}

}
