package smv.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import smv.mybatis.mapper.UserMapper;
import smv.mybatis.model.ListUser;
import smv.mybatis.model.User;
import smv.service.IService;

@Controller("/")
public class HomeController{
	@Autowired
	private UserMapper userMapper;
	@Resource(name = "userService")
	private IService<User> service;
	@RequestMapping("/create")
	@ResponseBody
	public User create(
			@RequestParam(name="name") String name, 
			@RequestParam(name="loginId") String loginId, 
			@RequestParam(name="password")String password){
		User user = service.created(name, loginId, password);
		return user;
	}
	@RequestMapping("/update")
	@ResponseBody
	public String update(){
		try {
			int i = service.randomUpdate();
			return "success:"+i;
		} catch (Exception e) {
			e.printStackTrace();
			return "fail";
		}
	}
	@RequestMapping("/delete")
	@ResponseBody
	public String delete(){
		try {
			int i = service.randomDelete();
			return "success:"+i;
		} catch (Exception e) {
			e.printStackTrace();
			return "fail";
		}
	}
	@RequestMapping("")
	public ModelAndView index(String name, User user, ListUser lu){
		ModelAndView mv = new ModelAndView("index");
		
		String testId = UUID.randomUUID().toString();
		User userTest = new User();
		userTest.setId(testId);
		userTest.setName("测试用户");
		userTest.setLoginId("测试登录账号");
		userTest.setPassword("测试密码");
		userTest.setCreatedAt(service.now());
		userMapper.save(userTest);
		userTest.setName("测试登录账号1");
		userMapper.update(userTest);
		userMapper.deleteById(testId);
		
		List<User> users = service.selectRandomsize();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("name", IService.USERNAME);
		param.put("loginId", IService.LOGINID);
		users.addAll(userMapper.dynamicSql(param));
		
		mv.addObject("name", name);
		mv.addObject("user", user);
		mv.addObject("lu", lu);
		mv.addObject("users", users);
		return mv;
	}
	
	@RequestMapping("test_data")
	@ResponseBody
	public boolean testData(Integer num){
		if(num == null || num < 1){
			num = 100;
		}
		for(int i = 0; i < num; i++){
			service.created(IService.USERNAME, IService.LOGINID, IService.PASSWORD);
		}
		return true;
	}

}
