package leap.performance.test.mybatis;

import java.util.Properties;

import javax.sql.DataSource;

import leap.core.annotation.Inject;

import org.apache.ibatis.datasource.DataSourceFactory;

public class MybatisDataSourceFactory implements DataSourceFactory{
	@Inject(name="default")
	private DataSource datasource;
	@Override
	public void setProperties(Properties props) {
	}

	@Override
	public DataSource getDataSource() {
		return datasource;
	}

}
