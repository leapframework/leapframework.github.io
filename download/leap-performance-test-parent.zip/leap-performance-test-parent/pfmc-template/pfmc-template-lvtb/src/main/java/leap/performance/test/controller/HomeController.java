package leap.performance.test.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import leap.core.AppContext;
import leap.core.annotation.Inject;
import leap.lang.New;
import leap.performance.test.engine.PerformanceTestEngine;
import leap.performance.test.engine.TemplateEngine;
import leap.performance.test.model.Performance;
import leap.performance.test.service.DataService;
import leap.web.annotation.Path;
import leap.web.view.ViewData;


public class HomeController {
	@Inject(name="testEngine")
	private PerformanceTestEngine testEngine;
	@Inject
	private DataService data;
	public void index(ViewData vd,Integer times) {
		if(times == null || times == 0){
			times = 100;
		}
		testEngine.variable(var());
		testEngine.testTiems(times);
		List<Performance> pers = testEngine.test();
		System.out.println("-------------测试结果----------------");
		System.out.println("测试环境-----------------------------");
		System.out.println("jdk8");
		System.out.println("结果数据-----------------------------");
		for(Performance per : pers){
			System.out.println("模板引擎:" + per.engine());
			System.out.println("\ttps(次/秒):" + per.tps());
			System.out.println("\ttime(毫秒):" + per.time());
			System.out.println("\t单次渲染吞吐量(字节):" + per.singleNout());
			System.out.println("\t全部渲染吞吐量(字节):" + per.totalNout());
			System.out.println("--------------------------");
		}
		vd.put("times", times);
		vd.put("pers", pers);
	}
	@Path("/{engineName}")
	public Object engine(String engineName){
		TemplateEngine engine = AppContext.factory().getBean(TemplateEngine.class, engineName);
		if(engine != null){
			String html = engine.process(var());
			Map<String, Object> result = New.hashMap("size",html.length());
			return result;
		}
		throw new RuntimeException("没有找到模板引擎:"+engineName);
	}
	
	private Map<String, Object> var(){
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("name", "template");
		var.put("users",data.users(100));
		return var;
	}
}
