package leap.fullstack.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import leap.core.annotation.Bean;
import leap.fullstack.model.User;
import leap.lang.New;
@Bean(id="userservice")
public class UserService implements IService<User>{
	@Override
	public User created(String name, String loginId, String password){
		User user = new User();
		user.setName(name);
		user.setLoginId(loginId);
		user.setPassword(password);
		user.setId(UUID.randomUUID().toString());
		user.setCreatedAt(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		user.create();
		return user;
	}

	@Override
	public int randomUpdate() {
		int num = RANDOM.nextInt(NUM);
		return User.updateAll(New.hashMap("createdAt", now()), "name LIKE ?", "%"+num+"%");
	}

	@Override
	public int randomDelete() {
		int num = RANDOM.nextInt(NUM);
		return User.deleteAll("name LIKE ?", "%"+num);
	}

	@Override
	public List<User> selectRandomsize() {
		//int num = RANDOM.nextInt(NUM);
		return User.<User>query("selectUserByName").param("nameLike", USERNAME).list();
	}
}
