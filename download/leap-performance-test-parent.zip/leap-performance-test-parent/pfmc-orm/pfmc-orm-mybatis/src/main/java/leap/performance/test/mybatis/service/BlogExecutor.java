package leap.performance.test.mybatis.service;

import leap.performance.test.mybatis.mapper.BlogMapper;
import leap.performance.test.mybatis.model.Blog;

public class BlogExecutor extends BaseExecutor<Blog, BlogMapper> {
	@Override
	protected Class<BlogMapper> getMapperType() {
		return BlogMapper.class;
	}
}
