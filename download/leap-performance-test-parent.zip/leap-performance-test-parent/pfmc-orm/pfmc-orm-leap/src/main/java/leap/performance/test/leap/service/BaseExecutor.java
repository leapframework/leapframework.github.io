package leap.performance.test.leap.service;

import leap.orm.dao.Dao;
import leap.orm.model.Model;
import leap.performance.test.service.SqlExecutor;

public abstract class BaseExecutor<T extends Model> implements SqlExecutor<T> {
	protected Dao dao = Dao.get();
}
