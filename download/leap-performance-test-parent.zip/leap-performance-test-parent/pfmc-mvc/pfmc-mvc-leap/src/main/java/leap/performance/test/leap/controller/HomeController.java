package leap.performance.test.leap.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import leap.performance.test.model.CollectionModel;
import leap.performance.test.model.JsonModel;
import leap.performance.test.model.ParamModel;
import leap.performance.test.model.User;
import leap.web.action.ControllerBase;
import leap.web.view.ViewData;

public class HomeController extends ControllerBase {
	public void index(ViewData vd,String name) {
		List<User> users = new ArrayList<User>();
		for(int i = 0; i < 500; i++){
			User user = new User();
			user.setName(name+i);
			user.setAge(i);
			users.add(user);
		}
		vd.put("users", users);
	}
	public void jsp(ViewData vd,String name, 
			ParamModel pm,
			CollectionModel cm){
		List<User> users = new ArrayList<User>();
		for(int i = 0; i < 500; i++){
			User user = new User();
			user.setName(name+i);
			user.setAge(i);
			users.add(user);
		}
		vd.put("pm", pm);
		vd.put("cm", cm);
		vd.put("users", users);
	}
	
	public JsonModel json(){
		JsonModel jm = new JsonModel();
		jm.setName("json");
		jm.setAge(40);
		jm = new JsonModel();
		jm.setName("json");
		jm.setAge(40);
		List<User> users = new ArrayList<User>();
		for(int i=0; i < 200; i ++){
			User user = new User();
			user.setName("user"+i);
			user.setAge(i);
			users.add(user);
		}
		jm.setUser(users);
		Map<String, Object> attr = new HashMap<>();
		attr.put("name", "jm");
		attr.put("age", 30);
		jm.setAttr(attr);
		return jm;
	}
}
