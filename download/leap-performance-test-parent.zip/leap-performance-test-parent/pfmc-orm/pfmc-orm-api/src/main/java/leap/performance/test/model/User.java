package leap.performance.test.model;

public interface User{
	public String getId();
	public void setId(String id);
	public String getName();
	public void setName(String name);
	public Integer getAge();
	public void setAge(Integer age);
	public String getCompanyId();
	public void setCompanyId(String companyId);
}
