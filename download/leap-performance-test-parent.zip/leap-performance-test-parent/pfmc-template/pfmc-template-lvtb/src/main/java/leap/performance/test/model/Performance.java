package leap.performance.test.model;

public interface Performance {
	/**
	 * @return 引擎吞吐量, 单位时间内引擎渲染次数, 单位: 次/秒
	 */
	public double tps();
	/**
	 * @return 引擎全部渲染的执行时间, 单位: 毫秒
	 */
	public long time();
	/**
	 * @return 引擎单次渲染的IO次数, 单位: 次
	 */
	public double singleNio();
	/**
	 * @return 全部IO次数
	 */
	public long totalNio();
	/**
	 * @return 引擎单次渲染的输出量, 单位: 字节(字符)
	 */
	public int singleNout();
	/**
	 * @return 全部输出量
	 */
	public long totalNout();
	/**
	 * @return 引擎单位时间的IO次数, 单位: 次/秒
	 */
	public int sio();
	/**
	 * @return 引擎单位时间的输出量, 单位: 字节(字符)/秒
	 */
	public int sout();
	/**
	 * @return 内存消耗, 内存取新生代之外的内存(新生代内存会被很快回收), 单位: 字节
	 */
	public long memory();
	/**
	 * @return 引擎名称
	 */
	public String engine();
	
}
