package leap.fullstack.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import leap.core.annotation.Inject;
import leap.fullstack.model.ListUser;
import leap.fullstack.model.User;
import leap.fullstack.service.IService;
import leap.lang.Beans;
import leap.lang.New;
import leap.orm.dao.Dao;
import leap.web.view.ViewData;

public class HomeController {
	@Inject(id="userservice")
	private IService<User> service;
	@Inject
	private Dao dao;
	public User create(String name, String loginId, String password){
		return service.created(name, loginId, password);
	}
	
	public String update(){
		try {
			int i = service.randomUpdate();
			return "success:"+i;
		} catch (Exception e) {
			return "fail";
		}
	}
	
	public String delete(){
		try {
			int i = service.randomDelete();
			return "success:"+i;
		} catch (Exception e) {
			return "fail";
		}
	}
	
	public boolean testData(Integer num){
		if(num == null || num < 1){
			num = 100;
		}
		for(int i = 0; i < num; i++){
			service.created(IService.USERNAME, IService.LOGINID, IService.PASSWORD);
		}
		return true;
	}
	
	public void index(ViewData vd, String name, User user, ListUser lu){
		
		String testId = UUID.randomUUID().toString();
		User userTest = new User();
		userTest.setId(testId);
		userTest.setName("测试用户");
		userTest.setLoginId("测试登录账号");
		userTest.setPassword("测试密码");
		userTest.setCreatedAt(service.now());
		dao.executeNamedUpdate("insertUser", Beans.toMap(userTest));
		userTest.setName("测试登录账号1");
		dao.executeNamedUpdate("updateByUserId", Beans.toMap(userTest));
		dao.executeNamedUpdate("deleteByUserId", New.hashMap("id",testId));
		
		List<User> users = service.selectRandomsize();
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("name", IService.USERNAME);
		param.put("loginId", IService.LOGINID);
		users.addAll(dao.createNamedQuery(User.class, "dynamicSql").params(param).list());
		
		vd.put("name", name);
		vd.put("user", user);
		vd.put("lu", lu);
		vd.put("users", users);
	}
}
