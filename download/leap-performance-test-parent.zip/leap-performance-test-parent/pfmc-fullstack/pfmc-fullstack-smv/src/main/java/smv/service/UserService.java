package smv.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import smv.mybatis.mapper.UserMapper;
import smv.mybatis.model.User;

@Service(value="userService")
public class UserService implements IService<User> {
	@Autowired
	private UserMapper userMapper;//注入dao

	@Override
	public User created(String name, String loginId, String password) {
		User user = new User();
		user.setName(name);
		user.setLoginId(loginId);
		user.setPassword(password);
		user.setId(UUID.randomUUID().toString());
		user.setCreatedAt(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		userMapper.save(user);
		return user;
	}

	@Override
	public int randomUpdate() {
		int num = RANDOM.nextInt(NUM);
		Timestamp time = now();
		return userMapper.updateByName("%"+num+"%", time);
	}

	@Override
	public int randomDelete() {
		int num = RANDOM.nextInt(NUM);
		return userMapper.deleteByName("%"+num);
	}

	@Override
	public List<User> selectRandomsize() {
		//int num = RANDOM.nextInt(NUM);
		List<User> user = userMapper.selectByName(USERNAME);
		return user;
	}
}
