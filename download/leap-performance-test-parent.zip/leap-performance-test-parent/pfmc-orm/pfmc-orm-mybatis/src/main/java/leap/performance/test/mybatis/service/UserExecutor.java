package leap.performance.test.mybatis.service;

import leap.performance.test.mybatis.mapper.UserMapper;
import leap.performance.test.mybatis.model.User;

public class UserExecutor extends BaseExecutor<User, UserMapper> {
	@Override
	protected Class<UserMapper> getMapperType() {
		return UserMapper.class;
	}
}
