package leap.performance.test.engine;

import java.net.MalformedURLException;
import java.util.Map;

import leap.core.AppContext;

public interface TemplateEngine {
	public TemplateEngine init(String tmplPath);
	public String process(Map<String, Object> map);
	public void testTemplateName(String name);
	default String name(){
		return this.getClass().getSimpleName();
	}
	default String rootPath(){
		String root = "/";
		try {
			root = AppContext.servletContext().getResource("/WEB-INF/views").getPath();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		}
		return root;
	}
}
