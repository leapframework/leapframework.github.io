package leap.performance.test.controller;


public interface Controller {
	public Object index(int num);
	public Object insert(int num);
	public Object delete(int num);
	public Object update(int num);
	public Object query(int num);
	/**
	 * 单独创建记录
	 * @param num
	 * @return
	 */
	public Object created(int num);
	/**
	 * 单独更新记录
	 * @param num
	 * @return
	 */
	public Object updated(int num);
	/**
	 * 单独删除记录
	 * @param num
	 * @return
	 */
	public Object deleted(int num);
	/**
	 * 单独测试动态sql
	 * @param num
	 * @return
	 */
	public Object dynamic(int num);
	/**
	 * 单独测试join
	 * @param num
	 * @return
	 */
	public Object join(int num);
	public Object testData();
	public Object clearData();
}
