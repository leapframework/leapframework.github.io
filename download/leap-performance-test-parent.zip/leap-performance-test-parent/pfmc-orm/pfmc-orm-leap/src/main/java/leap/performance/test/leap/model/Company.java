package leap.performance.test.leap.model;

import java.util.Map;

import leap.lang.New;
import leap.orm.annotation.Column;
import leap.orm.annotation.Id;
import leap.orm.annotation.Table;
import leap.orm.model.Model;

@Table("leap_company")
public class Company extends Model implements leap.performance.test.model.Company,Mapper{
	@Id
	@Column(name="id")
	private String id;
	@Column(name="name")
	private String name;
	@Column(name="member_num")
	private Integer memberNum;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getMemberNum() {
		return memberNum;
	}
	public void setMemberNum(Integer memberNum) {
		this.memberNum = memberNum;
	}
	@Override
	public Map<String, Object> toMap() {
		Map<String, Object> map = New.hashMap();
		map.put("id", id);
		map.put("name", name);
		map.put("memberNum", memberNum);
		return map;
	}
}
