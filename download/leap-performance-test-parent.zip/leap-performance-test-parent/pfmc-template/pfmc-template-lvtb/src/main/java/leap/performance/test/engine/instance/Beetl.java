package leap.performance.test.engine.instance;

import java.io.IOException;
import java.util.Map;

import leap.performance.test.engine.TemplateEngine;

import org.beetl.core.Configuration;
import org.beetl.core.GroupTemplate;
import org.beetl.core.Template;
import org.beetl.core.resource.FileResourceLoader;

public class Beetl implements TemplateEngine{
	private GroupTemplate engine;
	private FileResourceLoader resourceLoader;
	private Configuration cfg;
	private String template;
	public Beetl(String tmplPath) {
		init(tmplPath);
	}
	@Override
	public TemplateEngine init(String tmplPath) {
		String root = rootPath();
		resourceLoader = new FileResourceLoader(root);
		try {
			cfg = Configuration.defaultConfiguration();
		} catch (IOException e) {
			e.printStackTrace();
		}
		engine = new GroupTemplate(resourceLoader, cfg);
		return this;
	}

	@Override
	public String process(Map<String, Object> map) {
		Template t = engine.getTemplate(template);
		t.binding(map);
		return t.render();
	}
	@Override
	public void testTemplateName(String name) {
		this.template = name;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
}
