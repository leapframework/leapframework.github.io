package leap.performance.test.leap.model;

import java.util.Map;

public interface Mapper {
	public Map<String, Object> toMap();
}
