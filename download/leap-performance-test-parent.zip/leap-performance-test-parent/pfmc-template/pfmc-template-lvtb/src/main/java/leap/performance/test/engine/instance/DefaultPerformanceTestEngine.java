package leap.performance.test.engine.instance;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import leap.performance.test.engine.PerformanceTestEngine;
import leap.performance.test.engine.TemplateEngine;
import leap.performance.test.model.DefaultPerformance;
import leap.performance.test.model.Performance;

public class DefaultPerformanceTestEngine implements PerformanceTestEngine {
	private Map<String, Object> context;
	private int times = 100;
	private List<TemplateEngine> engines;
	private static DecimalFormat df = new DecimalFormat("######0.00"); 
	@Override
	public List<Performance> test() {
		for(TemplateEngine engine : engines){
			for(int i=0;i<5;i++){
				engine.process(context);
			}
		}
		List<Performance> results = new ArrayList<Performance>();
		for(TemplateEngine engine : engines){
			long size = 0;
			int single = 0;
			long begin = System.currentTimeMillis();
			for(int i=0;i<times;i++){
				single = engine.process(context).getBytes().length;
				size += single;
			}
			long end = System.currentTimeMillis();
			long minus = end - begin;
			DefaultPerformance performance = new DefaultPerformance();
			performance.setTime(minus);
			double tps = times*1000D/minus;
			performance.setTps(Double.parseDouble(df.format(tps)));
			performance.setCount(times);
			performance.setName(engine.name());
			performance.setSingleNout(single);
			performance.setTotalNout(size);
			results.add(performance);
		}
		return results;
	}

	@Override
	public void testEnginList(List<TemplateEngine> engines) {
		this.engines = engines;
	}

	@Override
	public void testTiems(int times) {
		this.times = times;
	}

	@Override
	public void variable(Map<String, Object> var) {
		this.context = var;
	}

	public List<TemplateEngine> getEngines() {
		return engines;
	}

	public void setEngines(List<TemplateEngine> engines) {
		this.engines = engines;
	}

	public Map<String, Object> getContext() {
		return context;
	}

	public void setContext(Map<String, Object> context) {
		this.context = context;
	}

	public int getTimes() {
		return times;
	}

	public void setTimes(int times) {
		this.times = times;
	}
}
