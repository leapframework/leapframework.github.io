package leap.performance.test.engine;

import java.util.List;
import java.util.Map;

import leap.performance.test.model.Performance;

public interface PerformanceTestEngine {
	/**
	 * 需要测试的引擎列表
	 * @param engines
	 */
	public void testEnginList(List<TemplateEngine> engines);
	/**
	 * 引擎重复渲染次数
	 * @param times
	 */
	public void testTiems(int times);
	/**
	 * 开始测试并获取测试结果
	 * @return
	 */
	public List<Performance> test();
	
	public void variable(Map<String, Object> var);
}
