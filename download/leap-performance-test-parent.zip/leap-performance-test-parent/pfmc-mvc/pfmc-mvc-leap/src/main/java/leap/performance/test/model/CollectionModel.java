package leap.performance.test.model;

import java.util.List;

public class CollectionModel {
	public List<ParamModel> pms;

	public List<ParamModel> getPms() {
		return pms;
	}

	public void setPms(List<ParamModel> pms) {
		this.pms = pms;
	}
	
}
