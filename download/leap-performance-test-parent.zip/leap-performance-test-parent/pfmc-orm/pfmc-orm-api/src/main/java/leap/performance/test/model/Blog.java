package leap.performance.test.model;

import java.sql.Timestamp;

public interface Blog{
	public String getId();
	public void setId(String id);
	public String getTitle();
	public void setTitle(String title);
	public String getAuthorId();
	public void setAuthorId(String authorId);
	public Timestamp getCreatedAt();
	public void setCreatedAt(Timestamp createdAt);
}
