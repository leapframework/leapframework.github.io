package leap.performance.test.mybatis;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.List;

import javax.sql.DataSource;

import leap.core.annotation.Inject;

import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.datasource.DataSourceFactory;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.session.TransactionIsolationLevel;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

public class MybatisIniter implements SqlSessionFactory {
	private SqlSessionFactory mybatis;
	@Inject(name = "mybatisDatasourceFactory")
	private DataSourceFactory datasourceFactory;
	private Configuration configuration;
	private List<MapperConfig> mapperConfigs;
	private String environment = "development";

	public void init() {
		if (mybatis != null) {
			return;
		}
		DataSource dataSource = datasourceFactory.getDataSource();
		TransactionFactory transactionFactory = new JdbcTransactionFactory();
		Environment environment = new Environment(this.environment,
				transactionFactory, dataSource);
		configuration = new Configuration(environment);
		loadMapper();
		mybatis = new SqlSessionFactoryBuilder().build(configuration);
	}

	private void loadMapper(){
		if(mapperConfigs == null){
			return;
		}
		for(MapperConfig conf:mapperConfigs){
			configuration.addMapper(conf.getType());
			InputStream inputStream = null;
			String xmlResource = conf.getType().getName().replace('.', '/') + ".xml";
			try {
				inputStream = Resources.getResourceAsStream(conf.getType().getClassLoader(),xmlResource);
				if(inputStream != null){
					continue;
				}
			} catch (IOException e) {
			} finally{
				if(inputStream != null){
					try {
						inputStream.close();
					} catch (IOException e) {
					}
				}
			}
			try {
				inputStream = Resources.getResourceAsStream(
						conf.getType().getClassLoader(),
						conf.getResource());
			} catch (IOException e) {
			}
			XMLMapperBuilder xmlParser = new XMLMapperBuilder(inputStream,
					configuration, conf.getResource(),
					configuration.getSqlFragments(), conf.getType().getName());
			xmlParser.parse();
		}
	}
	
	@Override
	public SqlSession openSession() {
		return mybatis.openSession();
	}

	@Override
	public SqlSession openSession(boolean autoCommit) {
		return mybatis.openSession(autoCommit);
	}

	@Override
	public SqlSession openSession(Connection connection) {
		return mybatis.openSession(connection);
	}

	@Override
	public SqlSession openSession(TransactionIsolationLevel level) {
		return mybatis.openSession(level);
	}

	@Override
	public SqlSession openSession(ExecutorType execType) {
		return mybatis.openSession(execType);
	}

	@Override
	public SqlSession openSession(ExecutorType execType, boolean autoCommit) {
		return mybatis.openSession(execType, autoCommit);
	}

	@Override
	public SqlSession openSession(ExecutorType execType,
			TransactionIsolationLevel level) {
		return mybatis.openSession(execType, level);
	}

	@Override
	public SqlSession openSession(ExecutorType execType, Connection connection) {
		return mybatis.openSession(execType, connection);
	}

	@Override
	public Configuration getConfiguration() {
		return mybatis.getConfiguration();
	}

	public List<MapperConfig> getMapperConfigs() {
		return mapperConfigs;
	}

	public void setMapperConfigs(List<MapperConfig> mapperConfigs) {
		this.mapperConfigs = mapperConfigs;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}
}
