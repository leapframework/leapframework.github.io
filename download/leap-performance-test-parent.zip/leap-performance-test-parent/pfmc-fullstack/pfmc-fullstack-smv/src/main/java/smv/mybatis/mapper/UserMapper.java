package smv.mybatis.mapper;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import smv.mybatis.model.User;

public interface UserMapper {

	public User selectById(Object id);
	public void save(User user);
	public void saveAll(Collection<User> users);
	public void delete(Collection<Object> ids);
	public void deleteById(Object id);
	public void update(User user);
	public List<User> select(Map<String, Object> params);
	public List<User> dynamicSql(Map<String, Object> params);
	public int updateByName(String nameLike, Timestamp time);
	public int deleteByName(String nameLike);
	public List<User> selectByName(String nameLike);


}
