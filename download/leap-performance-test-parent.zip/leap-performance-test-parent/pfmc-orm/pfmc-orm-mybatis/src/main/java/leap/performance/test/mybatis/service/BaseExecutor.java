package leap.performance.test.mybatis.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import leap.core.annotation.Inject;
import leap.performance.test.mybatis.mapper.Mapper;
import leap.performance.test.service.SqlExecutor;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public abstract class BaseExecutor<T,E extends Mapper<T>> implements SqlExecutor<T>{
	@Inject
	protected SqlSessionFactory factory;
	
	@Override
	public void insert(T t) {
		this.execute((mapper)->{
			mapper.insert(t);
		});
	}
	@Override
	public T selectById(Object id) {
		T t = this.getReturn((mapper)->{
			return mapper.selectById(id);
		});
		return t;
	}
	
	@Override
	public void update(T t) {
		this.execute((mapper)->{
			mapper.update(t);
		});
	}
	
	@Override
	public void beathDelete(Collection<?> ids) {
		this.execute((mapper)->{
			mapper.beathDelete(ids);
		});
	}
	
	@Override
	public void deleteById(Object id) {
		this.execute((mapper)->{
			mapper.deleteById(id);
		});
	}
	
	@Override
	public void beathInsert(Collection<T> collection) {
		this.execute((mapper)->{
			mapper.beathInsert(collection);
		});
	}
	
	@Override
	public List<T> select(String sqlKey, Map<String, Object> params) {
		List<T> list = this.getReturn((mapper)->{
			return mapper.select(params);
		});
		return list;
	}
	
	@Override
	public void deleteAll() {
		this.execute((mapper)->{
			mapper.deleteAll();
		});
	}
	@Override
	public List<T> dynamicSql(Map<String, Object> params) {
		return this.getReturn((mapper)->{
			return mapper.dynamicSql(params);
		});
	}
	@Override
	public List<?> joinSql(Map<String, Object> params) {
		return this.getReturn((mapper)->{
			return mapper.joinSql(params);
		});
	}
	
	public <R> R getReturn(ReturnExecutor<E,R> executor){
		SqlSession session = null;
		E mapper = null;
		R r = null;
		try {
			session = factory.openSession();
			mapper = session.getMapper(getMapperType());
			r = executor.getReturn(mapper);
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			if(session != null){
				session.commit();
				session.close();
			}
		}
		return r;
	}
	public void execute(NoReturnExecutor<E> executor){
		SqlSession session = null;
		E mapper = null;
		try {
			session = factory.openSession();
			mapper = session.getMapper(getMapperType());
			executor.noReturn(mapper);
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			if(session != null){
				session.commit();
				session.close();
			}
		}
	}
	protected abstract Class<E> getMapperType();
	
	@FunctionalInterface
	public interface ReturnExecutor<E,R>{
		public R getReturn(E mapper);
	}
	@FunctionalInterface
	public interface NoReturnExecutor<E>{
		public void noReturn(E mapper);
	}
}
