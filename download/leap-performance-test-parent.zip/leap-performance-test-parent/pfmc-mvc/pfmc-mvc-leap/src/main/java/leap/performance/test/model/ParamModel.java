package leap.performance.test.model;

public class ParamModel {
	private String string;
	private Integer integer;
	private User user;
	public String getString() {
		return string;
	}
	public void setString(String string) {
		this.string = string;
	}
	public Integer getInteger() {
		return integer;
	}
	public void setInteger(Integer integer) {
		this.integer = integer;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}
