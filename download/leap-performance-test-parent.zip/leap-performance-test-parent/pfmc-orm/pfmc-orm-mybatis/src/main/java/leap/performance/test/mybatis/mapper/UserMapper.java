package leap.performance.test.mybatis.mapper;

import leap.performance.test.mybatis.model.User;



public interface UserMapper extends Mapper<User>{
	
}
